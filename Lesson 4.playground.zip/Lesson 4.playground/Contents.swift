import Cocoa

// Классы, наследования, деинициализация, ARC и управление памятью
/*

 //Value Type: Int, Double, String, Array, Dictionary, Set, Struct, Enum, Tuple
 //Reference Type: Function, Closures, Class

/// 3 слеша пишет описание метода при вызове функции в подсказках
func threeslashes() {
    print("3слеша")
}
 // Требования-рекомендации:
 // булевые имена значений пишем через is.  var isDoorOpen: Bool
 // длинные инициализации разбивать по строкам
 // классы писать через final (зачит от него наследоваться нельзя) код будет работать быстрее

 // наследование мало используют т.к велик шанс ошибок. Если меняешь в родительском классе, то ошибки могут
 // выскочить в наследуемых классах. Используют Агрегацию и Композицию, а не наследование.

 //ARC будут спрашивать на собесах, ссылка на статью (выучить) https://habr.com/ru/company/hh/blog/546856/
*/

// классы и структуры
/*
class ParentClass {
    var array = [String]()
    var name: String
    var age: Int

    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
}

final class Son: ParentClass {

    func methods() {
        print("Hello \(name)")
    }
}

let son = Son(name: "vasia", age: 19)
son.methods() // ello vasia
print(son)


final class Doughter: ParentClass {

}
let doughter = ParentClass(name: "Vasilisa", age: 32)
print(doughter)
*/


//отличие классов и структур и их работа в памяти

//структура
/*
struct NameStruct {
    var name: String
    var age: Int
}

var strOne = NameStruct(name: "Max", age: 12)
var strTwo = NameStruct(name: "Jack", age: 15)
var strThree = NameStruct(name: "Ivan", age: 25)


strOne = strTwo
print(strOne.name) // Jack
strTwo = strThree
print(strTwo.name) // Ivan
strThree.name = "Kolia"
print(strThree.name) // Kolia

print("__________")

// структуры независимы. При изменении одной, ее копии не меняются

//класс
class NameClass {
    var name: String
    var age: Int
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
}

var calssOne = NameClass(name: "Макс", age: 12)
var classTwo = calssOne
var classThree = classTwo

calssOne.name = "Степа"
classThree.name = "kolia"

print(calssOne.name)// kolia
print(classTwo.name)// kolia
print(classThree.name)// kolia
*/
// при взаимосвязи классов они ссылаются на одну и ту же ссылку, при изменении одного класса меняется значение другого


//наследование
/*
class People {
    let name: String = "Джон"
    let surName: String = "Смит"

    var fullNmae: String {
        return("\(name) \(surName)")
    }

    func printFullName() {
        print(fullNmae)
    }

    func summa() {
        print(1+2)
    }
}
// как создать рабочий метод в наследуемом классе
class Man: People {

    override func printFullName() { // override переопределяем метод
        super.printFullName()       // Super вызываем метод родительского класса
        print("Раз Раз")
    }
    override func summa() {
        super.summa()
    }

}


let man = Man()
man.printFullName()
man.summa()
*/



// Инкапсуляция (private)
// это возможность скрытия свойств


/*
class People {
    private var name: String = "Петя"
}

let people = People() // в init нет варианта изменить name
print(people.name) // error: 'name' is inaccessible due to 'private'
*/


/*
class People {
    private(set) var name: String = "Петя" // добавляем set, работает только на чтение, изменять имя нельзя
}

let people = People() // по пержнему в init нет варианта изменить name
print(people.name) // но мы можем читать, но не изменять
*/

// используется чтобы скрыть какую то логику, которая используется только внутри данного класса
/*
class People {
    private var name: String = "Петя"

    private var count = 0 // count будет использоваться только здесь, его не нужно тянуть дальше. По этому делаем
                          // его невидимым в наследуемых классах через private
    func cycle() {
        while count > 0 {
            count += 1
            print("example")
        }
    }
}
*/


// ARC и управление памятью. ARC и Deinit работает только у классов
/*
class Person {
    var name: String
    init(name: String) {
        self.name = name
        print("\(name) инициализирован и создан в памяти")
    }

    deinit {
        print("\(name) удален из памяти")
    }
}

var ref1: Person?
var ref2: Person?
var ref3: Person?

ref1 = Person(name: "Jack")
ref2 = ref1
ref3 = ref1
//Jack инициализирован и создан в памяти
ref1 = nil
//Jack инициализирован и создан в памяти
ref2 = nil
//Jack инициализирован и создан в памяти
ref3 = nil
// Jack удален из памяти (не удалится пока на него ссылаются)
*/

//перекресные ссылки
// Симптомы: забивается память телефона, память растет с каждым действием пока приложение не крашнится.
//иногда очень сложно найти такие ссылки, так что уделять особое внимание
/*
class Hotel {
    var name: String //человек

    var apartament: Appartaments? // апартаменты

    init(name: String) {
        self.name = name
        print("Отель инициализирован и создан в памяти")

    }
    deinit {
        print("\(name) выезжает")
    }
}

class Appartaments {
    var room: String

    weak var hotel: Hotel? // отель

    init(room: String) {
        self.room = room
        print("аппартаменты инициализированы и созданы в памяти ")
    }
    deinit {
        print("Апартаменты \(room) освобождаются")
    }
}

// перекресные ссылки у Hotel и Appartaments

var objectHotel: Hotel?
var objectAppartament: Appartaments?

objectHotel = Hotel(name: "Вася Пупкин")
objectAppartament = Appartaments(room: "23")

objectHotel?.apartament = objectAppartament
objectAppartament?.hotel = objectHotel

//Отель инициализирован и создан в памяти
//аппартаменты инициализированы и созданы в памяти

objectHotel = nil
objectAppartament = nil
// Отель инициализирован и создан в памяти
//аппартаменты инициализированы и созданы в памяти
// ничего не изменилось, память не очистилась по тому, что
//var apartament: Appartaments? и var hotel: Hotel? две сильные ссылки, нужно к одной из них приписать weak


// добавили weak var hotel: Hotel?
objectHotel = nil
objectAppartament = nil
//Вася Пупкин выезжает
//Апартаменты 23 освобождаются

*/

