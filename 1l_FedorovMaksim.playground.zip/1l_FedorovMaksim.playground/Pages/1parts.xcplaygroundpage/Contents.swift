import Cocoa

let equation = "a(x^2)+bx-c=0"
let a = 3
let b = 7
let c = -6
let d = pow(Double(b),2) - (Double(4*a*c))
print(d)
if d > 0 {print("We have two finished")
}
else if d < 0 {print("we don't have finished")
    }
let x1 = ((Double(0-b))+sqrt(d)) / (Double(2*a))
print(x1)
//1й вариант решения
let x2 = ((Double(0-b))-sqrt(d)) / (Double(2*a))
print(x2)
//2й вариает решения
