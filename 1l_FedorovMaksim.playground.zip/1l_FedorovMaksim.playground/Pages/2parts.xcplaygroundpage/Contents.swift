//: [Previous](@previous)

import Foundation
import Darwin
import CoreGraphics

let cathetA:Float = 3
let cathetB:Float = 4
let square = (cathetA*cathetB) / 2
print(square)
let hypotinuse = sqrt(pow(cathetA,2) + pow(cathetB,2))
print(hypotinuse)
let perimeter = cathetA + cathetB + hypotinuse
print(perimeter)
