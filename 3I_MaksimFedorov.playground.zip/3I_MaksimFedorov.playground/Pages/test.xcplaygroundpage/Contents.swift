//: [Previous](@previous)
// больше ничего не понял, как сделать; прошу расписать, чтобы я разобрался самостоятельно
import Cocoa

import Foundation
var ship: Int?

enum Window {
    case open, close
}
enum Engine {
    case start, stop

}
enum TrunkVolumeFilled {
    case download (ship: Int)
    case upload (ship: Int)
  
}
enum TrunkVolume {
    case volume
}
struct SportCar {
    let brand: String
    let year: Int
    var window: Window {
        willSet {
            if window == .open {
                print("закрываем окно")
            
        } else {
        print("Открываем окно")
        }
        }
    }

    var trunkVolume: Int
    var trunkVolumeFilled: Int

    var engine: Engine
}
var sportcar1 = SportCar(brand: "Ferrari", year: 2003, window: .open, trunkVolume: 30, trunkVolumeFilled: 0, engine: .start)
sportcar1.window = .close

struct TrunkCar {
    let brand: String
    let year: Int
    var window: Window {
    willSet {
            if window == .close {
                print("Открываем окно")
            
        } else {
        print("закрываем окно")
        }
        }
    }

    var trunkVolumeFilled: Int
    
    
        
    
    var trunkVolume: Int

       var engine: Engine {
    
       willSet {
            if engine == .start {
                print("Заглушить двигатель")
    
            } else {
               print("Завести двигатель")
            }
        }
   }
    }
var trunkCar1 = TrunkCar(brand: "Kamaz", year: 2010, window: .close, trunkVolumeFilled: 300, trunkVolume: 1000, engine: .stop)

trunkCar1.window = .open
trunkCar1.engine = .start
