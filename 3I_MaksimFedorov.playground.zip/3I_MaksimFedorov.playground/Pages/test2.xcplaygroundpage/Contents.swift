//: [Previous](@previous)

import Foundation

enum Engine {
    case start, stop

}
enum Window {
    case open, close

}

struct SportCar {
    let brand: String
    let monufacturedYear: Int
    var trunkVolume: Int
    var filledTrunkVolume: Int?
    var window: Window
    var engine: Engine
}

var sportcar1 = SportCar(brand: "Ferrari", monufacturedYear: 2003, trunkVolume: 100, filledTrunkVolume: 0, window: .open, engine: .start)
